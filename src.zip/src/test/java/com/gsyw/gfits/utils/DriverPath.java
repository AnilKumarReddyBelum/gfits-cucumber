package com.gsyw.gfits.utils;

public interface DriverPath {
	String getPath();
}
