package com.gsyw.gfits.def;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gsyw.gfits.utils.ChromeBrowserDriverPath;
import com.gsyw.gfits.utils.DriverPath;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GfitsLoginPageWithScenarioOutlineDef {

	WebDriver driver;

	@Before
	public void setup() {
		DriverPath driverPath = new ChromeBrowserDriverPath();
		System.setProperty("webdriver.chrome.driver", driverPath.getPath());
		driver = new ChromeDriver();
	}

	@Given("^I open gsyw gfits login page$")
	public void I_open_gsyw_gfits_login_page() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://gsyw-gfits-ui.herokuapp.com/login");
	}

	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\" and click on SignIn button$")
	public void I_enter_username_and_password_fields_and_click_on_SignIn_button(String userName, String password) {
		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.tagName("button")).click();
	}

	@Then("^I can see home page elements$")
	public void I_can_see_homepage_elements() {
		if (driver.getCurrentUrl().contains("dashboard"))
			System.out.println("GfitsLoginPageWithScenarioOutlineDef - Test passed");
		else
			System.out.println("GfitsLoginPageWithScenarioOutlineDef - Test Failed");

		driver.close();
	}

	@When("^I enter invalid \"([^\"]*)\" and \"([^\"]*)\" and click on SignIn button$")
	public void I_enter_invalid_username_and_password_fields_and_click_on_SignIn_button(String userName,
			String password) {
		System.out.println("userName :: " + userName);
		System.out.println("password :: " + password);
		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.tagName("button")).click();
	}

	@Then("^I can see Login page elements$")
	public void I_can_see_loginpage_elements() {
		if (driver.getCurrentUrl().contains("login"))
			System.out.println("GfitsLoginPageWithScenarioOutlineDef - Test passed");
		else
			System.out.println("GfitsLoginPageWithScenarioOutlineDef - Test Failed");

		driver.close();
	}

	@After
	public void closeBrowser() {
		driver.quit();
	}

}
