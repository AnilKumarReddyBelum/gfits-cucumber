package com.gsyw.gfits.def;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gsyw.gfits.utils.ChromeBrowserDriverPath;
import com.gsyw.gfits.utils.DriverPath;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class GfitsSignUpPageDef {

	WebDriver driver;

	@Before
	public void setup() {
		DriverPath driverPath = new ChromeBrowserDriverPath();
		System.setProperty("webdriver.chrome.driver", driverPath.getPath());
		driver = new ChromeDriver();
	}

	@After
	public void closeBrowser() {
		driver.quit();
	}

	@Given("^I open Gfits login screen$")
	public void I_open_gsyw_gfits_login_page() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://gsyw-gfits-ui.herokuapp.com/login");
	}

	@Then("^I click on SignUp link$")
	public void I_click_on_SignUp_button() {
		driver.findElement(By.linkText("Sign Up")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Then("^I have to fill the \"([^\"]*)\" field$")
	public void I_have_to_fill_the_field(String userName) throws Throwable {
		System.out.println("userName -> " + userName);
		driver.findElement(By.id("userName")).sendKeys(userName);
	}

	@Then("^I have to select the Role as \"([^\"]*)\" dropdown$")
	public void I_have_to_select_the_userRole_dropdown(String userRole) throws Throwable {
		System.out.println("userRole -> " + userRole);
		driver.findElement(ByXPath.id("userRole")).sendKeys(userRole);
	}

	@Then("^I have to select the Country as \"([^\"]*)\" dropdown$")
	public void I_have_to_select_the_country_dropdown(String userLocation) throws Throwable {
		System.out.println("userLocation -> " + userLocation);
		driver.findElement(ByXPath.id("userLocation")).sendKeys(userLocation);
	}

	@Then("^I have to fill the valid \"([^\"]*)\" field$")
	public void I_have_to_fill_the_valid_emailId_field(String userEmailId) {
		System.out.println("userEmailId -> " + userEmailId);
		driver.findElement(By.id("emailId")).sendKeys(userEmailId);
	}

	@Then("^I have click on Next Button$")
	public void Click_on_next_button() {
		driver.findElement(By.tagName("button")).click();
	}

	// B
	@Then("^I have to select the bs as \"([^\"]*)\" dropdown$")
	public void I_have_to_select_the_business(String businessName) {
		System.out.println("businessName -> " + businessName);
		driver.findElement(ByXPath.id("businessName")).sendKeys(businessName);
	}

	// S
	@Then("^I have to select the sbs as  \"([^\"]*)\" dropdown$")
	public void I_have_to_select_the_subbusiness(String subBusinessName) {
		System.out.println("subBusinessName -> " + subBusinessName);
		driver.findElement(ByXPath.id("subBusinessName")).sendKeys(subBusinessName);
	}

	// A
	@Then("^I have to select the appr as  \"([^\"]*)\" dropdown$")
	public void I_have_to_select_the_approver(String approveOrRejectBy) throws InterruptedException {
		System.out.println("approver -> " + approveOrRejectBy);
		driver.findElement(ByXPath.id("approveOrRejectBy")).sendKeys(approveOrRejectBy);
	}

	@Then("^I have to fill the comments as \"([^\"]*)\" text area$")
	public void I_have_to_fill_the_text_area(String requestorComments) throws Throwable {
		System.out.println("requestorComments -> " + requestorComments);
		driver.findElement(By.id("requestorComments")).sendKeys(requestorComments);
	}

	@Then("^I have to see the URL which contains register$")
	public void I_have_to_see_the_URL_which_contains_register() throws Throwable {
		driver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if (driver.getCurrentUrl().contains("register")) {
			System.out.println("current url -> " + (driver.getCurrentUrl()));
		}
	}

}
