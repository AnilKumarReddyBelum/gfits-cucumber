package com.gsyw.gfits.def;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gsyw.gfits.utils.ChromeBrowserDriverPath;
import com.gsyw.gfits.utils.DriverPath;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class GfitsLoginPageDef {

	WebDriver driver;

	@Before
	public void setup() {
		DriverPath driverPath = new ChromeBrowserDriverPath();
		System.setProperty("webdriver.chrome.driver", driverPath.getPath());
		driver = new ChromeDriver();
	}

	@Given("^I open Gfits$")
	public void I_open_Gfits() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://gsyw-gfits-ui.herokuapp.com/login");
	}

	@When("^I should see username and password fields$")
	public void I_should_see_username_and_password_fields() {
		if (driver.findElement(By.name("userName")).isDisplayed()
				&& driver.findElement(By.name("password")).isDisplayed()) {
			System.out.println("GfitsLoginPageDef - Test 1 Pass");
		} else {
			System.out.println("GfitsLoginPageDef - Test 1 failed");
		}

		driver.close();
	}

	@After
	public void closeBrowser() {
		driver.quit();
	}

}
