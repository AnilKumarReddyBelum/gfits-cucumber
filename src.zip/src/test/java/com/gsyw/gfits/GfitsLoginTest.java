package com.gsyw.gfits;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;
import cucumber.api.junit.Cucumber.Options;

@RunWith(Cucumber.class)
@Options(features = {"src/test/resources/com/gsyw/gfits/gfitsSignUp.feature"})
public class GfitsLoginTest {

}
